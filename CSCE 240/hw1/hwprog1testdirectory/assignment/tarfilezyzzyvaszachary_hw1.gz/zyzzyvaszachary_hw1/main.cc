#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Zachary Zyzzyvas. All rights reserved.
 * Date: 14 May 2016
**/

int main(int argc, char *argv[]) {
  cout << "Hello, world." << endl;
  cout << "My name is Zachary Zyzzyvas." << endl;

  return 0;
}
