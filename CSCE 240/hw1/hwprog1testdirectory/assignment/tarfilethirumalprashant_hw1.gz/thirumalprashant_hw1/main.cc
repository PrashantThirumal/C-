#include <iostream>
using namespace std;

/****************************************************************
 * Main program for Homework 1.
 *
 * Author/copyright:  Prashant Thirumal. All rights reserved.
 * Date: 3 September 2018
**/

int main(int argc, char *argv[]) {
  cout << "Hello, world." << endl;
  cout << "My name is Prashant Thirumal." << endl;

  return 0;
}
